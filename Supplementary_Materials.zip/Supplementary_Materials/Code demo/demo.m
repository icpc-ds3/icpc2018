clc,clear
addpath('.\liblinear\');
addpath('.\DS3\');
dissimilarityType = 'Chi'; % type of pairwise dissimilarities, {'Euc','Euc2','L1','Chi'}

% data of prior version
X_data = load('ant13.mat'); 
X_data = X_data.ant13;

% data of current version
Y_data = load('ant14.mat');
Y_data = Y_data.ant14;
LOC = Y_data(:,11); % the effort

Ng = size(X_data,2)-1;
N = size(X_data,1);
X = X_data(:,1:Ng)';
Y = Y_data(:,1:Ng)';

% compute the dissimilarity matrix
D = computeDissimilarity(dissimilarityType,X,Y);
D = D ./ max(max(D));

lamada = 0.026;

Z = ds3solver_regularized(D,lamada); %the DS3 method
sInd = findRepresentatives(Z);  %find the indexs of the representative modules of the prior version using DS3 method

prior_version_selected = X_data(sInd,:); %the modules of the representative modules of the prior version
Indicators = LR(prior_version_selected,Y_data, LOC);% calculatethe evaluation indicators